#ifndef CONFIG_H
#define CONFIG_H

#define DILITHIUM_MODE 5

#define CRYPTO_ALGNAME "Dilithium5"
#define DILITHIUM_NAMESPACE(s) pqcrystals_dilithium5_avx2##s

#endif
