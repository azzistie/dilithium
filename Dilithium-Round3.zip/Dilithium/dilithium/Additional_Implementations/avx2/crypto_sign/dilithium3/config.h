#ifndef CONFIG_H
#define CONFIG_H

#define DILITHIUM_MODE 3

#define CRYPTO_ALGNAME "Dilithium3"
#define DILITHIUM_NAMESPACE(s) pqcrystals_dilithium3_avx2##s

#endif
